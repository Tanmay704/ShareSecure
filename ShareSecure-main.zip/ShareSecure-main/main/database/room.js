import mongoose from 'mongoose';
  const { Schema } = mongoose;
  const roomSchema = new Schema({
    
  });

  export { roomSchema };